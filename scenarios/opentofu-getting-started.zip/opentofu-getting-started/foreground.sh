mkdir ~/scenario && cd ~/scenario
