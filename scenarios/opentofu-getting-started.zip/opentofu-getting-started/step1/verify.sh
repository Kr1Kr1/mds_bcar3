#!/bin/bash
tofu --version
