#!/bin/bash

/bin/true